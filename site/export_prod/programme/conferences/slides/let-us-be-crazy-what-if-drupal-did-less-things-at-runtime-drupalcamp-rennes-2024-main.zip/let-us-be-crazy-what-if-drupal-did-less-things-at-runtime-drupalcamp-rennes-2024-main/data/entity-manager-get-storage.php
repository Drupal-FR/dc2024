<?php

$storage = $entityManager->getStorage('node');
$storage->load($id);
