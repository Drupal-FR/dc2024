<?php

anArticle()
    ->published()
    ->with(aLink());
